/**
 * @file Circle.hpp
 * @author Oriol Gorriz (origovi2000@gmail.com)
 * @brief Contains the Circle class specification
 * @version 1.0
 * @date 2022-10-31
 * 
 * @copyright Copyright (c) 2022 BCN eMotorsport
 */

#pragma once

#include <cmath>
#include <iostream>

#include "structures/Node.hpp"

/**
 * @brief Represents a circle in 2D coordinates.  表示二维坐标中的圆
 */
class Circle {
 private:
  /**
   * @brief The center of the Circle both in local and global coordinates.  在局部坐标和全局坐标中，圆的中心。
   */
  Point center_, centerGlobal_;

  /**
   * @brief The radius of the Circle to the power of two.  圆半径的2次方。
   */
  double radSq_;

 public:
  /**
   * @brief Construct a new Circle object.
   * \a n0, \a n1, \a n2 are 3 Node(s) belonging to the Circle's circumference.
   * 
   * @param[in] n0
   * @param[in] n1 
   * @param[in] n2 
   */
  Circle(const Node &n0, const Node &n1, const Node &n2);

  /**
   * @brief Checks if Node \a n is inside the Circle's circumference.  检查节点\ n是否在圆的周长内。 
   * 
   * @param n 
   */
  bool containsNode(const Node &n) const;

  /**
   * @brief Returns the Circle's center in local coordinates.    以局部坐标返回圆的中心。  
* / 
   */
  const Point &center() const;

  /**
   * @brief Returns the Circle's center in global coordinates.   在全局坐标中返回圆的中心。 
   */
  const Point &centerGlobal() const;
};