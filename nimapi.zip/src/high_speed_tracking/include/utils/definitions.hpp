/**
 * @file definitions.hpp
 * @author Oriol Gorriz (origovi2000@gmail.com)
 * @brief Contains the definitions (aliases) needed throughout the program.
 * @version 1.0
 * @date 2022-10-31
 * 
 * @copyright Copyright (c) 2022 BCN eMotorsport
 */

#pragma once

#include <list>
#include <unordered_set>

#include "structures/Edge.hpp"
#include "structures/Triangle.hpp"

using TriangleSet = std::unordered_set<Triangle>;   // 容器 无序集合 这行代码定义了一个名为TriangleSet的类型别名，它是一个无序集合（unordered_set）类型，其中存储的元素是Triangle类型的对象。
using EdgeSet = std::unordered_set<Edge>;

using HeurInd = std::pair<double, size_t>;

using Tracklimits = std::pair<std::vector<Node>, std::vector<Node>>;                //包含左侧变量与右侧变量的类型
