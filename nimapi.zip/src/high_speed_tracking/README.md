# Urinay

Urinay是一种色盲路径+轨迹限制算法，用于计算Formula Student无人驾驶汽车交叉赛道的中心线和轨迹限制，而不需要感知锥的颜色。它使用Delaunay三角剖分和有限启发式思考树搜索，只取锥体位置和汽车姿态。为[BCN eMotorsport Formula Student team](https://bcnemotorsport.upc.edu)制作，由我(Oriol Gorriz)完全使用c++并与ROS一起工作。

## Disclaimer
If you use this algorithm for a Formula Student competition, the **only** thing I ask for is acknowledgment for the project. **Always** reference the team ***BCN eMotorsport***.
如果你在学生方程式比赛中使用这个算法，我唯一需要的就是对项目的认可。**始终**引用团队***BCN eMotorsport***。

# #依赖性
- [Ubuntu](https://ubuntu.com) (tested on 20.04)
- [ROS](http://wiki.ros.org/ROS/Installation) (tested on Noetic)
- [Eigen](http://eigen.tuxfamily.org/index.php?title=Main_Page)
- *as_msgs*: The team's proprietary communication messages package. Change it for yours.
   *as_msgs*:团队专有的通信消息包。把它换成你的。 

## 1. Delaunay Triangulation  德劳内三角
该方法的第一步包括使用检测到的锥作为2D空间中的点来获得Delaunay三角剖分(一组三角形)。
这个集合是使用我的[Bowyer-Watson算法](https://en.wikipedia.org/wiki/Bowyer%E2%80%93Watson_algorithm)实现计算的。这是一个迭代过程，计算为O(*n*log*n*)，即*n*点的数量。锥数较多的三角剖分的执行时间约为1ms。*无花果。1*表示三角形集合(红色)和每条边的中点(绿色)

<p align="center">
  <img src="./documentation/assets/urinay_triangulation_1.png" alt="Delaunay triangulation" width="500" /><br />
  Figure 1: Delaunay triangulation
</p>

## 2. Filtering and midpoints     过滤和中点
下一步将使用中点找到轨道的中线，但如图*图所示。1*，中点太多，可能导致轨道中线计算错误。为了避免这个问题，我们过滤:
-三角形:删除那些有大边或小角的三角形。
-中点:移除周围没有三角形的中点。
如图*所示。2*，我们已经可以看到一个非常清晰的路径(中线)的绿色点。.

<p align="center">
  <img src="./documentation/assets/urinay_triangulation_3.png" alt="Filtered Delaunay triangulation" width="500" /><br />
  Figure 2: Filtered Delaunay triangulation
</p>

## 3. Midline calculation  中线计算
现在我们需要从过滤后的中点中获取一条中线。这个中线将是一个中点数组，按照汽车到达这些中点的顺序排列。
Urinay通过实现迭代启发式的高度限制树搜索解决了这个问题。

### 3.1. Tree search  树搜索
树搜索为算法提供了一定的“智能”，当然我们可以通过查看距离和角度迭代地将最佳中点附加到中线上，但这最终不会得到最佳的整体中线。我们需要考虑那些在当地不是“最好”的选择。
这个树搜索只给出了**下一个从起点开始属于中线的中点。为了获得完整的中线，将执行对树搜索的多次调用。
搜索定义如下:
1. **起点**将是中线距离汽车最近的点，如果中线为空，则为汽车的位置。
2. 这个点将是树的根，步骤2-7将对树的每个点*p*执行，直到为每个点找到停止条件。这些都是:
-没有找到可能的中点。
—点的树径达到最大高度阈值。
3.所有中点的**半径**将被考虑。
4. 将进行过滤，将删除以下中点:
-任何中点与最后一个点的角度**太大(避免点在后面和封闭曲线)。
-任何中点都在最后一条边的同一侧，确保路径**穿过**的每个中点边(避免在轨道限制上反弹)。
-[未应用于第一个中点]路径中已经包含**的任何中点**(避免创建错误的循环)。
-与中线平均边长相比，任何边缘太大或太小的中点(避免不正确的中线)。
-任何中点，当附加到路径创建一个交集(在路径本身)。
5. 将计算每个剩余中点的启发式**值。
6. **丢弃所有启发式超过阈值的中点。
7. 附加所有剩余的点作为*p*的子。
8. 找到最佳路径。这将是**最长的路径**(注意路径长度最多是树的高度)。如果两条路径长度相等，则启发式和最小的路径将占优。

1. The **starting point** will be the midline's closest point to the car, or the car's position if the midline is empty.
2. This point will be the root of the tree, steps 2-7 will be performed for each point *p* of the tree until a stop condition is found for every point. These are:
    - No possible midpoints are found.
    - The point's tree path reaches a maximum height threshold.
3. All midpoints within a **radius** of the point will be considered.
4. A filtering will be carried out, the following midpoints will be removed:
    - Any midpoint creating an **angle** too big with last point (avoid points behind and closed curves).
    - Any midpoint being in the same side of last edge, make sure the path **crosses** every midpoint edge (avoid bouncing on track limits).
    - [Not applied to first midpoint] Any midpoint **already contained** in the path (avoid creating incorrect loops).
    - Any midpoint whose edge is too big or too small compared to the midline average edge length (avoid incorrect midline).
    - Any midpoint that when appended to the path creates an intersection (on the path itself).
5. A **heuristic** value for each of the remaining midpoints will be calculated.
6. **Discard** all midpoints whose heuristic exceeds a threshold.
7. Append all remaining points as sons of *p*.
8. Find the best path. This will be the **longest path** (note that a path length will be at most the tree height). If two paths have equal length the one with smallest sum of heuristics will prevail.

### 3.2. Loop closure 循环关闭
Obviously we want to detect and compute the whole track midline. Urinay does so by checking if the loop is closed every time a new midpoint is added to the midline. There are two problems here:
显然，我们想检测和计算整个轨道中线。Urinay是这样做的:每当一个新的中点被添加到中线时，
检查循环是否关闭。这里有两个问题
1. How we detect a loop closure? If the following conditions are met:
    - The midline has a **length** greater than a threshold.
    - The first and last points of the midline are **closer** than a threshold.
2. The tree search will never take points already contained in the midline. It can fail before reaching the end of the midline (finding a longer path) and it will fail taking the first midline's midpoint (already contained). We solve the problem by letting the tree search take all midpoints that close the loop and any midpoint (contained or not) **after** closing the loop.
2. 树搜索永远不会取已经包含在中线中的点。它可能在到达中线的终点之前失败(找到一个更长的路径)，并且它将失败于第一个中线的中点(已经包含)。我们通过让树搜索获取所有关闭循环的中点和在**关闭循环后的任何中点(包含或不包含)来解决这个问题。

## 4. Track limits computation     航迹极限计算
When guiding the car through the obtained midline, the planner (an algorithm that tells the car exactly where to go using the midline) will also need the track limits so the car might not follow the midline strictly but also optimize its path (knowing the track width at every moment).
当引导汽车通过获得的中线时，规划器(一种算法，告诉汽车使用中线去哪里)也需要轨道限制，因此汽车可能不会严格遵循中线，但也会优化其路径(知道每一刻的轨道宽度)。

To calculate the track limits having the midline is a relatively easy task knowing that every point in the midline has its correspondant edge in the triangle set. The two points that create this edge will be part of the track limits.
计算有中线的轨迹极限是一个相对容易的任务，因为中线上的每个点在三角形集中都有对应的边。形成这条边的两个点将成为赛道限制的一部分。

If we iterate the midline and we find which side of the track every point of the midpoint's edge belongs to, an aggregation of these points create the track limits.
如果我们迭代中线，并找到中点边缘的每个点都属于轨道的哪一侧，这些点的聚合就创建了轨道限制。

## 5. Midline accumulation  中线积累
We need to accumulate the midline so when the car moves we still know which was the midline the car has already driven through and to close the loop when we have already seen the whole track. There is another problem, we cannot compute again and again the midline from the beginning of the track because it would take longer to compute and it may fail if we lose the cones of the beginning (or a lot of false positives are detected).

This is why program has also the car's position in the track. Knowing where the car is at every moment gives the possibility to compute the midline from the car's position and then merge it with last iteration's midline, as seen in *Fig. 3*. This way, when a circular midline is detected, the program can communicate it to the path planning (and loop path optimizer) and stop.
这就是为什么程序也有赛车在赛道上的位置。知道汽车在每个时刻的位置，就有可能从汽车的位置计算中线，然后将其与上次迭代的中线合并，如图*Fig所示。3 *。这样，当检测到圆形中线时，程序可以将其传递给路径规划(和循环路径优化器)并停止。

## 6. Result
The result can be seen in *Fig. 3*. Urinay always chooses the best-longest way, this is why sometimes it wants to take an incorrect path but amends it once the correct path is perceived.
结果如图*所示。3 *。尿尿总是选择最好最长的路，这就是为什么有时它想要走一条不正确的路，但一旦发现正确的路，它就会修正它。

<p align="center">
  <img src="./documentation/assets/urinay_1.gif" alt="Urinay's path+tracklimits" width="500" /><br />
  Figure 3: Urinay's path+tracklimits
</p>

## 7. Safety considerations
The following considerations have been taken into account when design and implementation of Urinay:
1. No abusive use of pointers: In the program there are some places where data is duplicated with the intention to maintain modularity, make a procedure easier to undersand or to avoid a possible invalid pointer.
2. Maximum computating time guarantee: For this application, a solution which takes too long to compute is not realistic. This is the algorithm that "tells" the car the track path, if it takes too long, the car may crash into the cones. To avoid that 3 mechanisms are used:
    - Tree height limit: The height of the search tree will always be limited to a parameter (usually 10, at maximum).
    - Tree sons numer limit: The number of next possible points will be cut down to a parameter (usually 2).
    - Computing time limit: Even if the mentioned restrictions are not sufficent to guarantee, a time limit for every tree search is applied. This way, if a particular search takes too long, e.g. when too many cone false positives are given, the best option when the time limit is hit will be considered as valid.