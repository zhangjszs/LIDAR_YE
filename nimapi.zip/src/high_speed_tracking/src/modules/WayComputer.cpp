/**
 * @file WayComputer.cpp
 * @author Oriol Gorriz (origovi2000@gmail.com)
 * @brief Contains the WayComputer class member functions implementation
 * @version 1.0
 * @date 2022-10-31
 *
 * @copyright Copyright (c) 2022 BCN eMotorsport
 */

#include "modules/WayComputer.hpp"
/* ----------------------------- Private Methods ---------------------------- */
/* ----------------------------- 这段代码中的while循环遍历三角剖分中的每个三角形，并检查它们是否包含超过允许的最长边。
如果三角形的一个边长超过了设定的最大边长，则将其标记为需要删除，并跳出内层循环。如果没有超过，
则继续检查下一个边。如果所有边都符合要求，则不将该三角形删除。最后，外层循环将继续遍历下一个三角形。
 ---------------------------- */
//  这段代码的作用是对三角剖分进行过滤，
//  删除边长大于`params_.max_triangle_edge_len`或角度小于`this->params_.min_triangle_angle`的三角形。
//  如果满足条件则从`triangulation`中删除该三角形。

void WayComputer::filterTriangulation(TriangleSet &triangulation) const {
  auto it = triangulation.begin();
  while (it != triangulation.end()) {
    bool removeTriangle = false;
    // Look for edges longer than accepted  寻找比接受的更长的边
    for (const Edge &e : it->edges) {
      if (e.len > params_.max_triangle_edge_len) {
        removeTriangle = true;
        break;
      }
    }

    // Look for angles smaller than accepted   //寻找小于可接受的角度
    if (!removeTriangle) {
      for (const double &angle : it->angles()) {
        if (angle < this->params_.min_triangle_angle) {
          removeTriangle = true;
          break;
        }
      }
    }

    if (removeTriangle)
      it = triangulation.erase(it);
    else
      it++;
  }
}

// 本回答由gpt.tool00.com代为生成，请认准本站。
// 这段代码的作用是过滤掉所有距离三角形外接圆圆心太远的边的中点，以确保生成的路径不会离开三角形内部。
//具体来说，它执行以下操作：
// 1. 构建一个包含所有三角形外接圆圆心的 k-d 树，以便快速查找最近的圆心。
// 2. 遍历所有边的中点，如果其距离最近的圆心超过了最大阈值，则将该边从集合中删除。
// 3. 返回过滤后的边集合。
// 其中，`params_.max_dist_circum_midPoint` 是一个参数，表示中点和外接圆圆心之间的最大距离。
// 如果该距离超过了该参数的值，则该中点被认为是无效的。


// 这段代码的作用是对边集进行过滤，去掉与三角形外接圆心距离超过阈值的中点对应的边。
// 具体来说，它首先将所有三角形的外接圆心存储在一个向量中，并使用这些点建立一个 k-d 树。
// 然后，它迭代遍历边集中的所有边，对于每个边，计算其中点，并在 k-d 树中查找最接近该中点的外接圆心。
// 如果找到了最接近的外接圆心，并且该圆心与中点之间的距离超过了阈值，则将该边从边集中删除。
// 最终，该函数返回的边集中只包含与三角形外接圆心距离不超过阈值的中点对应的边。
// 这个操作可以用来过滤掉那些不规则的、太大或太小的三角形，从而保证三角剖分的质量。


// 在 Urinay 算法中，我们的目标是优化从起点到终点的路径，路径的距离应该被优化为最短。
// 如果中点到离它最近的圆心的距离超过了 params_.max_dist_circum_midPoint 所设置的最大距离限制，
// 说明这个中点距离其所对应的圆心较远，并且移除这样的中点会使路径较短。我们可以考虑这样一个情况：
// 如果中点与其最近的圆心之间的距离过大，那么路径就不能被充分优化。因为路径朝向这个中点就会导致绕路，
// 如果这样的中点被多次包含在路径中，就会导致路径总长度较长。因此，
// 过滤超过最大距离限制的中点能够有效地排除掉那些会导致绕路行驶的路径，
// 提高路径规划效率，并使得得到的路径更接近最短路径。
void WayComputer::filterMidpoints(EdgeSet &edges, const TriangleSet &triangulation) const {
  std::vector<Point> circums(triangulation.size());                                           //存放圆心的容器
  std::transform(triangulation.begin(), triangulation.end(), circums.begin(),
                 [](const Triangle &t) -> const Point & { return t.circumCenter(); });             
  KDTree circumKDTree(circums);

  // Perform the filtering
  //这段代码用于对路径中的每个中点进行过滤，快速定位离每个中点最近的圆心，
  //如果距离超过设定的最大限制值，就说明当前中点导致的路径不可行，将其所在的边从路径中移除。
  auto it = edges.begin();
  while (it != edges.end()) {
    Point midPoint = it->midPoint();
    KDTData<size_t> nearestCC = circumKDTree.nearest_index(midPoint);
    if (bool(nearestCC) and Point::distSq(circums[*nearestCC], midPoint) > pow(params_.max_dist_circum_midPoint, 2)) {
      it = edges.erase(it);
    } else {
      it++;
    }
  }
}

double WayComputer::getHeuristic(const Point &actPos, const Point &nextPos, const Vector &dir) const {
  double distHeur = Point::dist(actPos, nextPos);

  double angle = Vector(actPos, nextPos).angleWith(dir);
  double angleHeur = -log(std::max(0.0, ((M_PI_2 - abs(angle)) / M_PI_2) - 0.2));

  return params_.heur_dist_ponderation * distHeur + (1 - params_.heur_dist_ponderation) * angleHeur;
}

inline double WayComputer::avgEdgeLen(const Trace *trace) const {
  if (not trace or trace->empty())
    return this->way_.getAvgEdgeLen();
  else if (this->way_.empty())
    return trace->avgEdgeLen();
  else
    return ((trace->avgEdgeLen() * trace->size()) / (trace->size() + this->way_.size())) + ((this->way_.getAvgEdgeLen() * this->way_.size()) / (trace->size() + this->way_.size()));
}

void WayComputer::findNextEdges(std::vector<HeurInd> &nextEdges, const Trace *actTrace, const KDTree &midpointsKDT, const std::vector<Edge> &edges) const {
  nextEdges.clear();

  const Edge *actEdge = nullptr;
  Point actPos(0, 0);
  Point lastPos(0, 0);

  // Set actual and last position    设置实际位置和最后位置
  if (actTrace and not actTrace->empty()) {
    actEdge = &edges[actTrace->edgeInd()];
    actPos = edges[actTrace->edgeInd()].midPoint();
    if (actTrace->size() >= 2) {
      lastPos = edges[actTrace->before().edgeInd()].midPoint();
    }
  }
  if (not this->way_.empty()) {
    if (not actEdge) {
      actEdge = &this->way_.back();
      actPos = this->way_.back().midPoint();
      if (this->way_.size() >= 2) {
        lastPos = this->way_.beforeBack().midPoint();
      }
    } else if (actTrace->size() < 2) {
      lastPos = this->way_.back().midPoint();
    }
  }

  // Set dir vector
  Vector dir;
  if (actEdge and (this->way_.size() >= 2 or actTrace))  // This condition avoids setting a vector pointing backwards
    dir = Vector(lastPos, actPos);                     //计算方向向量
  else
    dir = Vector(1, 0);

  // Find all possible edges in a specified radius  在指定半径内找到所有可能的边
  std::unordered_set<size_t> nextPossibleEdges = midpointsKDT.neighborhood_indices_set(actPos, params_.search_radius);

  // Discard edges by specifications  /按规格丢弃边
  auto it = nextPossibleEdges.begin();
  while (it != nextPossibleEdges.end()) {
    const Edge &nextPossibleEdge = edges[*it];
    // 如果下列条件为真，则当前迭代的Edge将被移除
    bool removeConditions = actEdge and (
    
      nextPossibleEdge == *actEdge or

      //如果 nextPossibleEdge 的中点与当前方向向量 dir 之间的角度差大于 this->params_.max_angle_diff，
      //则将其从集合中删除，因为这样的边不符合行驶方向。
      abs(dir.angleWith(Vector(actPos, nextPossibleEdge.midPoint()))) > this->params_.max_angle_diff or

      //如果当前路径没有闭合，则删除任何已经包含在路径中但不是闭合路径的边，因为这样会导致路径无法闭合
      (not this->way_.closesLoopWith(nextPossibleEdge) and (not actTrace or not actTrace->isLoopClosed()) and this->way_.containsEdge(nextPossibleEdge)) or

      //删除任何中点和上一个位置的中点位于 actEdge 同侧的边，因为这样的边可能会使车辆在轨道边缘反弹。
      ((this->way_.size() >= 2 or actTrace) and Vector::pointBehind(actEdge->midPoint(), lastPos, actEdge->normal()) == Vector::pointBehind(actEdge->midPoint(), nextPossibleEdge.midPoint(), actEdge->normal())) or

      // 删除长度比平均边长小于或大于一定比例的边，因为这些边可能是异常值，会影响路径的平滑性
      (nextPossibleEdge.len < (1 - this->params_.edge_len_diff_factor) * this->avgEdgeLen(actTrace) or nextPossibleEdge.len > (1 + this->params_.edge_len_diff_factor) * this->avgEdgeLen(actTrace)) or

      // 如果不允许路径交叉，则删除任何可能导致路径交叉的边。
      (not this->params_.allow_intersection and (not actTrace or not actTrace->isLoopClosed()) and not this->way_.closesLoopWith(nextPossibleEdge) and this->way_.intersectsWith(nextPossibleEdge))
    );

    if (removeConditions)
      it = nextPossibleEdges.erase(it);
    else
      it++;
  }

  // Get the heuristics for all possible next edges and filter them (only the
  // ones having a heuristic small enough will prevail)
  std::vector<HeurInd> privilege_runner;
  privilege_runner.reserve(nextPossibleEdges.size());
  for (const size_t &nextPossibleEdgeInd : nextPossibleEdges) {
    double heuristic = this->getHeuristic(actPos, edges[nextPossibleEdgeInd].midPoint(), dir);
    if (heuristic <= params_.max_next_heuristic) privilege_runner.emplace_back(heuristic, nextPossibleEdgeInd);
  }

  // Copy the n best HeurInd(s) into the nextEdges vector, according to
  // cppreference.com, this is O(nlogn)
  nextEdges.resize(std::min(privilege_runner.size(), (size_t)params_.max_search_options));
  std::partial_sort_copy(privilege_runner.begin(), privilege_runner.end(), nextEdges.begin(), nextEdges.end());
}

size_t WayComputer::treeSearch(std::vector<HeurInd> &nextEdges, const KDTree &midpointsKDT, const std::vector<Edge> &edges) const {
  std::queue<Trace> cua;
  for (const HeurInd &nextEdge : nextEdges) {
    bool closesLoop = this->way_.closesLoopWith(edges[nextEdge.second]);
    cua.emplace(nextEdge.second, nextEdge.first, edges[nextEdge.second].len, closesLoop);
  }
  // The provisional best is the Trace with smaller heuristic, i.e. the front one
  Trace best = cua.front();

  // This loop will realize the tree search and get the longest (& best) path.
  // The loop will stop if the tree search is completed or a time limit has
  // been exceeded.
  ros::WallTime searchBeginTime = ros::WallTime::now();
  while (not cua.empty()) {
    if (ros::WallTime::now() - searchBeginTime > ros::WallDuration(params_.max_treeSearch_time)) {
      ROS_WARN("[urinay] Time limit exceeded in tree search.");
      break;
    }
    Trace t = cua.front();
    cua.pop();

    bool trace_at_max_height = false;

    if (t.size() >= params_.max_search_tree_height)
      trace_at_max_height = true;
    else
      this->findNextEdges(nextEdges, &t, midpointsKDT, edges);

    if (trace_at_max_height or nextEdges.empty()) {
      // Means that this trace is finished, should be considered as the "best"
      // trace. The method of choosing the best trace is as follows:
      // 1. The longest trace wins.
      // 2. If the size is equal, then the trace with smallest accum heuristic wins.
      // Note that here, no trace is added to the queue.
      if (t.size() > best.size() or (t.size() == best.size() and t.sumHeur() < best.sumHeur())) {
        best = t;
      }
    } else {
      // Add new possible traces to the queue
      for (const HeurInd &nextEdge : nextEdges) {
        Point actPos = edges[t.edgeInd()].midPoint();
        bool closesLoop = this->way_.closesLoopWith(edges[nextEdge.second], &actPos);
        Trace aux = t;
        aux.addEdge(nextEdge.second, nextEdge.first, edges[nextEdge.second].len, closesLoop);
        cua.push(aux);
      }
    }
  }
  // The next point will be the first point of the best path
  return best.first().edgeInd();
}
// 这段代码实现了一个路径规划算法，输入参数是一组边（edges），表示一个地图，输出结果是一条路径（way_）。算法的具体实现如下：

// 1. 首先，从路径的起点（离车最近的点）开始，将路径中的所有边都删除，只保留起点。

// 2. 然后，将所有边的中点作为点，建立一个 k-d 树，以便更快地找到最近的点。

// 3. 接下来，算法会在地图上进行搜索，每次找到一条边，就将其加入路径中，直到无法再加入边为止。具体搜索过程如下：

// a. 首先，找到一组可能的下一条边（nextEdges），这些边与当前路径的最后一条边相邻。

// b. 然后，在这组可能的边中，找到一条具有最低启发式评估（heuristic Trace）的边，并将其加入路径中。

// c. 检查路径是否形成了一个闭环，如果是，则算法结束，并返回一条闭合的路径。

// d. 如果路径未闭合，则继续搜索下一条边，直到无法再加入边为止。

// 4. 最终，算法输出的路径就是从起点开始，依次经过所有加入的边所形成的路径。







//这段代码实现了计算路径的功能。具体来说，它将一组边作为输入，
//然后使用启发式搜索算法来计算最佳路径。算法的基本思路是在每个步骤中选择一个最优的中间点，
//然后将其添加到路径中。这个过程会一直进行下去，直到无法找到更好的中间点为止。
void WayComputer::computeWay(const std::vector<Edge> &edges) {
  this->way_.trimByLocal();                                        // 去掉所有从最靠近汽车(包括)到最后的边    不是很情操逻辑赋值

  // Build a k-d tree of all midpoints so is cheaper to find closest points 建立一个所有中点的k-d树，这样找到最近的点更便宜
  std::vector<Point> midpoints(edges.size());            //放所有中点
  std::transform(edges.begin(), edges.end(), midpoints.begin(),
                 [](const Edge &e) -> Point { return e.midPoint(); });
  KDTree midpointsKDT(midpoints);

  std::vector<HeurInd> nextEdges;                       //这个容器接下来用于暂存当前路径可拓展的下一组边   索引和启发评估值

  // 获取第一组可能的边
  this->findNextEdges(nextEdges, nullptr, midpointsKDT, edges);
//主外循环，此循环的每一次迭代都要添加一个
//路径的中点。
  while (not nextEdges.empty() and ros::ok()) {
    size_t nextEdgeInd = this->treeSearch(nextEdges, midpointsKDT, edges);

    // Append the new Edge
    this->way_.addEdge(edges[nextEdgeInd]);

    // Check for loop closure
    if (this->way_.closesLoop()) {
      this->wayToPublish_ = this->way_.restructureClosure();
      this->isLoopClosed_ = true;
      return;
    }

    // Get next set of possible edges
    this->findNextEdges(nextEdges, nullptr, midpointsKDT, edges);
  }
  this->wayToPublish_ = this->way_;
}

/* ----------------------------- Public Methods ----------------------------- */
// 构造函数初始化
WayComputer::WayComputer(const Params::WayComputer &params) : params_(params) {
  Way::init(params.way);
}
void WayComputer::stateCallback(const common_msgs::HUAT_Carstate::ConstPtr &ins){
    geometry_msgs::Pose pose;
    pose.position.x = ins->car_state.x;
    pose.position.y = ins->car_state.y;
    pose.position.z = 0;
    tf::Quaternion qAux;
    qAux.setRPY(0.0, 0.0, (ins->car_state.theta));
    tf::quaternionTFToMsg(qAux, pose.orientation);
    tf::poseMsgToEigen(pose, this->localTf_);
    this->localTf_ = this->localTf_.inverse();
    this->localTfValid_ = true;
}





// // 这段代码的作用是将汽车的位置和方向转换为一个局部坐标系，并将其逆变换存储在this->localTf_中。
// void WayComputer::stateCallback(const fsd_common_msgs::CarState::ConstPtr &data) {
//   geometry_msgs::Pose pose;
//   pose.position = data->odom.position;
//   // tf::Quaternion qAux;
//   // qAux.setRPY(0.0, 0.0, data->odom.heading);
//   // tf::quaternionTFToMsg(qAux, pose.orientation);
//   // tf::poseMsgToEigen(pose, this->localTf_);
//   //pose.position.x = data->odom.x;
//  // pose.position.y = data->odom.y;
//   //pose.position.z = 0;
//   tf::Quaternion qAux;                                                       //四元数类型表示物体姿态信息
//   qAux.setRPY(0.0, 0.0, data->heading);                   //基于全局的偏航角   这里需要考虑  目前是认为可以直接拿来使用
//   tf::quaternionTFToMsg(qAux, pose.orientation);
//   tf::poseMsgToEigen(pose, this->localTf_);
//   this->localTf_ = this->localTf_.inverse();                    //全局变换矩阵准换为本地变换矩阵
//   this->localTfValid_ = true;                                  //全局转本地后供其他模块使用
// }


/* ----------------------------- 先判断车状态是否能够收到----------------------------- */
void WayComputer::update(TriangleSet &triangulation) {
  if (not this->localTfValid_) {
    ROS_WARN("[urinay] CarState not being received.");
    return;
  }

  // #0:   最后更新方式(这将用于计算raplan标志) 
  this->lastWay_ = this->way_;

  // #1: Remove all triangles which we know will not be part of the track.删除所有三角形，我们知道不会是轨道的一部分,设置角度和边长
  this->filterTriangulation(triangulation);

   //  #2:提取所有的中点没有重复，通过一个EdgeSet做到这一点   无序会自动去除重复
  EdgeSet edgeSet;
  for (const Triangle &t : triangulation) {
    for (const Edge &e : t.edges) {
      edgeSet.insert(e);
    }
  }

//    #3:过滤中点。 只有那些周围有一个圆心的。这里得出的结果就是已经过滤完成的中点
  this->filterMidpoints(edgeSet, triangulation);

  // 将此集合转换为vector
  std::vector<Edge> edgeVec;                                   //这时的edgeVec等于去掉不符合规则的中点的edgeSet
  edgeVec.reserve(edgeSet.size());                                 
  for (const Edge &e : edgeSet) {
    edgeVec.push_back(e);              
  }

  // #4: Update all local positions (way and edges) with car tf
  // 边全部转换为车身坐标系下                    这里是从哪里获得的什么坐标系  这个地方要懂
  this->way_.updateLocal(this->localTf_);
  for (const Edge &e : edgeVec) {
    e.updateLocal(this->localTf_);
  }

  // #5: 通过中点进行搜索，以获得一条路径。
  this->computeWay(edgeVec);

  // #6: Visualize
  Visualization::getInstance().visualize(edgeSet);
  Visualization::getInstance().visualize(triangulation);
  Visualization::getInstance().visualize(this->wayToPublish_);
}

const bool &WayComputer::isLoopClosed() const {
  return this->isLoopClosed_;
}

void WayComputer::writeWayToFile(const std::string &file_path) const {
  std::ofstream oStreamToWrite(file_path);
  oStreamToWrite << this->wayToPublish_;
  oStreamToWrite.close();
}

std::vector<Point> WayComputer::getPath() const {
  return this->wayToPublish_.getPath();
}

Tracklimits WayComputer::getTracklimits() const {
  return this->wayToPublish_.getTracklimits();
}

  common_msgs::HUAT_PathLimits WayComputer::getPathLimits() const {
  common_msgs::HUAT_PathLimits res;
  res.stamp = ros::Time::now();

  // res.replan indicates if the Way is different from last iteration's// res.replan指示方法是否与上次迭代不同
  res.replan = this->way_ != this->lastWay_;

  // Fill path  //填充路径
  std::vector<Point> path = this->wayToPublish_.getPath();
  res.path.reserve(path.size());
  for (const Point &p : path) {
    res.path.push_back(p.gmPoint());
  }

  // Fill Tracklimits
  Tracklimits tracklimits = this->wayToPublish_.getTracklimits();
  res.tracklimits.stamp = res.stamp;
  res.tracklimits.left.reserve(tracklimits.first.size());
  for (const Node &n : tracklimits.first) {
    res.tracklimits.left.push_back(n.cone());
  }
  for (const Node &n : tracklimits.second) {
    res.tracklimits.right.push_back(n.cone());
  }

  // res.tracklimits.replan indicates if the n midpoints in front of the car
  // have varied from last iteration
  res.tracklimits.replan = this->way_.quinEhLobjetiuDeLaSevaDiresio(this->lastWay_);
  return res;
}
void  GeoDetic_TO_ENU(double lat, double lon, double h, double lat0, double lon0, double h0, double enu_xyz[3])
{
	  double a, b, f, e_sq;
	 a = 6378137;
	 b = 6356752.3142;
	f = (a - b) / a;e_sq = f * (2 - f);
	// 站点（非原点）
	double lamb, phi, s, N, sin_lambda, cos_lambda, sin_phi, cos_phi, x, y, z;
	lamb = lat;  
	phi = lon;
	s = sin(lamb);
	N = a / sqrt(1 - e_sq * s * s);

	sin_lambda = sin(lamb);
	cos_lambda = cos(lamb);
	sin_phi = sin(phi);
	cos_phi = cos(phi);

	x = (h + N) * cos_lambda * cos_phi;
	y = (h + N) * cos_lambda * sin_phi;
	z = (h + (1 - e_sq) * N) * sin_lambda;
	// 原点坐标转换
	double lamb0, phi0, s0, N0, sin_lambda0, cos_lambda0, sin_phi0, cos_phi0, x0, y0, z0;
	lamb0 = lat0;
	phi0 = lon0;
	s0 = sin(lamb0);
	N0 = a / sqrt(1 - e_sq * s0 * s0);

	sin_lambda0 = sin(lamb0);
	cos_lambda0 = cos(lamb0);
	sin_phi0 = sin(phi0);
	cos_phi0 = cos(phi0);

	x0 = (h0 + N0) * cos_lambda0 * cos_phi0;
	y0 = (h0 + N0) * cos_lambda0 * sin_phi0;
	z0 = (h0 + (1 - e_sq) * N0) * sin_lambda0;
	// ECEF 转 ENU
	double xd, yd, zd, t;
	xd = x - x0;
	yd = y - y0;
	zd = z - z0;
	t = -cos_phi0 * xd - sin_phi0 * yd;

	enu_xyz[0] = -sin_phi0 * xd + cos_phi0 * yd;
	enu_xyz[1] = t * sin_lambda0 + cos_lambda0 * zd;
	enu_xyz[2] = cos_lambda0 * cos_phi0 * xd + cos_lambda0 * sin_phi0 * yd + sin_lambda0 * zd;

  ROS_INFO("输出转换完成坐标");   
  std::cout << "current_x = "<<enu_xyz[0] <<"current_y = "<<enu_xyz[1]<<std::endl;
}