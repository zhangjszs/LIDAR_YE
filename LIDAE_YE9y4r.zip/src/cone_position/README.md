# cone_position
# Overall Functionality

This code subscribes to cone position messages from sensors and car state messages. It processes the cone positions to build a map of cones with unique IDs while filtering out duplicate detections. The cone map is published for other nodes to use.

# Main Components

- Subscribers:
    - /cone_position - cone position point cloud 
    - /Carstate - car position and orientation

- Publishers:
    - /newconeposition - publishes cone map 
    - /coneMarker - RViz visualizations
    - /globalMapOnly - point cloud of all cones

- Main loop:
    - Spin callbacks for cone and car state messages
    - Call functions to process messages

# Cone Position Processing

- When new cone data arrives:
    - Transform cone points to base link frame based on car orientation
    - For first message, assign new IDs and publish 
    - For subsequent messages:
        - Check distance to existing cones 
        - If close to existing, update average position
        - If far, assign new ID
    - Add to kd-tree for fast lookups
    - Publish transformed cone map
    - Visualize cones in RViz
    
- Outputs:
    - coneMap message - contains map of cones with IDs and positions
    - RViz cones - visualizes current cones
    - globalMapOnly - all cone points combined
    
# Car State Processing

- Extract car position and orientation 
- Print for debugging
- Used to transform cones to base link frame

So in summary, this takes raw cone data, processes it to build a map, and publishes the map for other nodes. The car state is used to transform coordinates.
