/**
 * @file main.cpp
 * @author Oriol Gorriz (origovi2000@gmail.com)
 * @brief Main file of Urinay, creates all modules, subcribers and publishers.
 * @version 1.0
 * @date 2022-10-31
 * 
 * @copyright Copyright (c) 2022 BCN eMotorsport
 */

// #include <fsd_common_msgs/ConeArray.h>
#include <common_msgs/HUAT_PathLimits.h>
#include <common_msgs/HUAT_cone.h>
#include <common_msgs/HUAT_Tracklimits.h>
#include <common_msgs/HUAT_map.h>

#include <ros/package.h>
#include <ros/ros.h>
#include <sys/stat.h>

#include <iostream>

#include "modules/DelaunayTri.hpp"
#include "modules/Visualization.hpp"
#include "modules/WayComputer.hpp"
#include "utils/Time.hpp"

//发布者在此初始化
ros::Publisher pubPartial;                //部分
ros::Publisher pubFull;                      //完整

WayComputer *wayComputer;
Params *params;

void callback_ccat( const common_msgs::HUAT_map::ConstPtr &data) {
  if (data->cone.empty()) {
    ROS_WARN("[urinay] reading empty set of cones.");
    return;
  }

  Time::tick("computation");  //开始测量时间

 //转换为节点向量
 //这行代码的作用是在`vector` `nodes`中预留足够的空间，以容纳`data->cones`中的元素。
 //这样做可以避免在添加元素时因为重新分配内存而导致的性能问题
  //这里有个置信度的问题   可能是不需要考虑  不考虑就注销掉
  std::vector<Node> nodes;                                                                                                  
  // nodes.reserve(data->cone.size());   
  for (const common_msgs::HUAT_cone &c : data->cone) {
    // if (c.confidence >= params->main.min_cone_confidence) 
      nodes.emplace_back(c);
  }

// Delaunay三角测量  得出的是一个类型 方便后续的计算
  TriangleSet triangles = DelaunayTri::compute(nodes);

//用新的三角测量方法更新    根据车状态实时更新这个情况
  wayComputer->update(triangles);

//发布循环并将tracklimits写入文件
// 这段代码是在检测路径是否闭合的情况下执行的。如果路径闭合，它会执行以下操作：

// 1. 发布完整路径的限制条件（pathLimits）到ROS话题pubFull中。

// 2. 输出一个信息，表示路径已闭合。

// 3. 创建一个名为“loops”的文件夹（如果不存在），并将路径写入名为“loop.unay”的文件中。

// 4. 如果参数params->main.shutdown_on_loop_closure为true，则关闭ROS节点，结束程序运行。

// 5. 最后，它会结束计算时间的测量，并输出一个信息表示程序已结束。
  if (wayComputer->isLoopClosed()) {
    pubFull.publish(wayComputer->getPathLimits());
    ROS_INFO("[urinay] Tanco loop");
    std::string loopDir = params->main.package_path + "/loops";
    mkdir(loopDir.c_str(), 0777);
    wayComputer->writeWayToFile(loopDir + "/loop.unay");
    if (params->main.shutdown_on_loop_closure) {
      Time::tock("computation");  //结束测量时间
      ROS_INFO("[urinay] Tingui bon dia :)");
      ros::shutdown();
    }
  }
//发布部分
  else {
    pubPartial.publish(wayComputer->getPathLimits());
  }

  Time::tock("computation");  //结束测量时间
}

//主函数
int main(int argc, char **argv) {
  setlocale(LC_ALL,"");
  ros::init(argc, argv, "urinay");
  ros::NodeHandle *const nh = new ros::NodeHandle;
  params = new Params(nh);   //加载参数
  wayComputer = new WayComputer(params->wayComputer);  //这句代码的意思是：创建一个名为wayComputer的指针，指向一个WayComputer对象，该对象的构造函数使用params->wayComputer参数来初始化。然后，使用wayComputer计算新的轨迹。
  Visualization::getInstance().init(nh, params->visualization);      //获取可视化处理  init()函数可能是用于初始化Visualization对象的状态或资源

  ros::Subscriber subCones = nh->subscribe(params->main.input_cones_topic, 10000, callback_ccat); 
  ros::Subscriber subPose = nh->subscribe(params->main.input_pose_topic, 10000, &WayComputer::stateCallback, wayComputer);
//`nh` 是一个指向 `ros::NodeHandle` 对象的指针，表示当前节点的句柄。
//`params` 是一个指向 `Params` 对象的指针，表示当前节点的参数配置。
//`subPose` 是一个 `ros::Subscriber` 对象，表示创建的订阅者。
//`params->main.input_pose_topic` 是一个字符串，表示订阅的话题名称，这个名称是从参数配置中获取的。
//`1` 表示订阅队列的大小，即最多缓存多少条未处理的消息。
//`&WayComputer::stateCallback` 是一个回调函数的指针，表示当接收到新消息时，应该调用哪个函数进行处理。这个函数属于 `WayComputer` 类。
//`wayComputer` 是一个指向 `WayComputer` 对象的指针，表示当前节点使用的路径规划器

  pubPartial = nh->advertise<common_msgs::HUAT_PathLimits>(params->main.output_partial_topic, 10000);
  pubFull = nh->advertise<common_msgs::HUAT_PathLimits>(params->main.output_full_topic, 10000);

  ros::spin();
}