/**
 * @file DelaunayTri.cpp
 * @author Oriol Gorriz (origovi2000@gmail.com)
 * @brief Contains the DelaunayTri class member functions implementation
 * @version 1.0
 * @date 2022-10-31
 * 
 * @copyright Copyright (c) 2022 BCN eMotorsport
 */

#include "modules/DelaunayTri.hpp"

/* ----------------------------- Private Methods ---------------------------- */
// 目的为了构建一个超级大三角形，完成包含所有点的工作，做这个工作的原因保证后续三角剖分的正确性与完整性
Triangle DelaunayTri::superTriangle(const std::vector<Node> &nodes) {
  // 找到最大和最小的坐标  
  double xmax = nodes.front().x();                                         //初始化  第一个点的x坐标 nodes.front().x()
  double xmin = nodes.front().x();
  double ymax = nodes.front().y();
  double ymin = nodes.front().y();
  for (const Node &n : nodes) {
    xmax = std::max(xmax, n.x());
    xmin = std::min(xmin, n.x());
    ymax = std::max(ymax, n.y());
    ymin = std::min(ymin, n.y());
  }

// 计算一个矩形框的中心点坐标，
  const double dx = xmax - xmin;
  const double dy = ymax - ymin;
  const double dmax = std::max(dx, dy);                           //这行代码的作用是找到dx和dy中的最大值，并将其赋值给变量dmax。
  const double midx = (xmin + xmax) / 2.0;
  const double midy = (ymin + ymax) / 2.0;

  const Node n0 = Node::superTriangleNode(midx - 20 * dmax, midy - dmax);
  const Node n1 = Node::superTriangleNode(midx, midy + 20 * dmax);
  const Node n2 = Node::superTriangleNode(midx + 20 * dmax, midy - dmax);

  return {n0, n1, n2};
}

/* ----------------------------- Public Methods ----------------------------- */

TriangleSet DelaunayTri::compute(const std::vector<Node> &nodes) {
  if (nodes.size() < 3) return {};                                                        

  TriangleSet triangulation;

  // 添加一个足够大的三角形来包含所有的点
  triangulation.insert(superTriangle(nodes));

  // 把所有的点一次加一个到三角剖分中
  for (const Node &n : nodes) {
    TriangleSet badTriangles;

  //首先找到所有由于插入而不再有效的三角形
    for (const Triangle &t : triangulation) {
      if (t.circleContainsNode(n)) {
        badTriangles.insert(t);
      }
    }

    EdgeSet polygon;

    for (const Triangle &t : badTriangles) {
      for (const Edge &e : t.edges) {
        bool shared = false;
        for (const Triangle &t2 : badTriangles) {
          if (&t != &t2 and t2.containsEdge(e)) {
            shared = true;
            break;
          }
        }
        if (not shared) {
          polygon.insert(e);
        }
      }
    }

   //从三角剖分数据结构中移除每个坏三角形
    for (const Triangle &t : badTriangles) {
      triangulation.erase(t);
    }

 //重新三角化多边形孔
 //对于第二步，它遍历多边形孔的边界，
 //对于每条边，它在三角剖分中添加一个新的三角形，该三角形的顶点为当前点和该边的两个端点。
 //生成新的三角形
    for (const Edge &e : polygon) {
      triangulation.emplace(e, n);
    }
  }

  //删除所有属于超级三角形的三角形 

//在第三步中，需要删除所有属于超级三角形的三角形，
//这是因为这些三角形不是待分割区域内的实际三角形，
//它们只是为了构建Delaunay三角剖分而添加的虚拟三角形。
//因此，这些三角形需要从三角剖分中移除，以得到最终的正确结果。
  auto it = triangulation.begin();
  while (it != triangulation.end()) {
    if (it->anyNodeInSuperTriangle()) {
      it = triangulation.erase(it);
    } else {
      it++;
    }
  }

  return triangulation;
}
//剖分三角化完成

// 这段代码实现了多边形的三角剖分算法。该算法的主要思路是：首先将多边形的边界点插入到一个超级三角形中，然后按照一定规则不断加入新的点，同时删除与该点相邻的坏三角形，最后删除所有属于超级三角形的三角形。

// 具体步骤如下：

// 1. 构建超级三角形，将多边形的边界点插入到其中。

// 2. 依次加入多边形中的每个点：

//    a. 找出包含该点的所有三角形，并将这些三角形标记为“坏三角形”。

//    b. 找出所有与该点相邻的边界边，将这些边按照逆时针方向组成一个多边形。

//    c. 从三角剖分数据结构中移除所有坏三角形。

//    d. 重新三角化多边形孔，对于每条边，在三角剖分中添加一个新的三角形，该三角形的顶点为当前点和该边的两个端点。

// 3. 删除所有属于超级三角形的三角形。

// 4. 返回最终的三角剖分结果。

// 值得注意的是，该算法的时间复杂度为O(nlogn)，其中n为多边形的顶点数。


// Triangle是一个自定义类型，用于表示一个三角形。它可能包含三个顶点的坐标、
// 三个顶点的索引或其他相关信息，具体取决于实现。在这个上下文中，
// Triangle是一个结构体或类，具有一些成员函数来检查三角形是否包含某个点、是否与另一个三角形相邻等。