/**
 * @file Node.cpp
 * @author Oriol Gorriz (origovi2000@gmail.com)
 * @brief Contains the Node class member functions implementation
 * @version 1.0
 * @date 2022-10-31
 * 
 * @copyright Copyright (c) 2022 BCN eMotorsport
 */

#include "structures/Node.hpp"

const uint32_t Node::SUPERTRIANGLE_BASEID;
uint32_t Node::superTriangleNodeNum = 0;

/* ----------------------------- Private Methods ---------------------------- */

//这段代码是定义了一个名为Node的类，该类有两个私有成员变量：point_和id，
//以及一个公有成员变量belongsToSuperTriangle_。在构造函数中，传入两个double类型的参数x和y，
//用于初始化point_，同时将id设为一个常量SUPERTRIANGLE_BASEID加上一个静态成员变量superTriangleNodeNum，
//这个静态成员变量每次加1并对3取模，以实现超级三角形节点的id循环使用。最后，belongsToSuperTriangle_被设置为true。
Node::Node(const double &x, const double &y)
    : point_(x, y), id(SUPERTRIANGLE_BASEID + superTriangleNodeNum), belongsToSuperTriangle_(true) {
  superTriangleNodeNum++;
  superTriangleNodeNum %= 3;
}

/* ----------------------------- Public Methods ----------------------------- */

Node::Node(const double &x, const double &y, const double &xGlobal, const double &yGlobal, const uint32_t &id)
    : point_(x, y), pointGlobal_(xGlobal, yGlobal), id(id), belongsToSuperTriangle_(false) {}

Node::Node(const common_msgs::HUAT_cone &c)
    : Node(c.position_baseLink.x, c.position_baseLink.y, c.position_global.x, c.position_global.y, c.id) {}

const double &Node::x() const {
  return this->point_.x;
}

const double &Node::y() const {
  return this->point_.y;
}

bool Node::operator==(const Node &n) const {
  return n.id == this->id;
}

bool Node::operator!=(const Node &n) const {
  return not(*this == n);
}

Node Node::superTriangleNode(const double &x, const double &y) {
  return Node(x, y);
}

const bool &Node::belongsToSuperTriangle() const {
  return belongsToSuperTriangle_;
}

void Node::updateLocal(const Eigen::Affine3d &tf) const {
  this->point_ = this->pointGlobal().transformed(tf);
}

const Point &Node::point() const {
  return this->point_;
}

const Point &Node::pointGlobal() const {
  return this->pointGlobal_;
}

double Node::distSq(const Point &p) const {
  return (this->x() - p.x) * (this->x() - p.x) + (this->y() - p.y) * (this->y() - p.y);
}

double Node::angleWith(const Node &n0, const Node &n1) const {
  return abs(Vector(this->point(), n0.point()).angleWith(Vector(this->point(), n1.point())));
}

common_msgs::HUAT_cone Node::cone() const {
  common_msgs::HUAT_cone res;
  res.id = this->id;
  res.position_global.x= this->pointGlobal().gmPoint().x;
  res.position_global.y= this->pointGlobal().gmPoint().y;
  res.type = 4;  // None  不清楚这个用来干啥 先注释
  return res;
}

std::ostream &operator<<(std::ostream &os, const Node &n) {
  os << "N(" << n.x() << ", " << n.y() << ")";
  return os;
}